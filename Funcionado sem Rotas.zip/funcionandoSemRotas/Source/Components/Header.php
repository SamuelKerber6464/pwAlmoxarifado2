<header>

  <?php

  //   session_start();
  // print_r($_SERVER['REQUEST_URI']); 


  if (isset($_SESSION['admin'])) {
  ?>
    <div class='upsideBtns'>
      <a href='../../index.php' class='defaultBtn btnRedirecionador'>Home</a>
      <a href='../../Themes/App/itemsListPage.php' class='defaultBtn btnRedirecionador'>Lista itens</a>
      <a href='../../Themes/App/registerItemsPage.php' class='defaultBtn btnRedirecionador'>Cadastrar Item</a>
      <a href='../../Themes/Admin/listEmployeesPage.php' class='defaultBtn btnRedirecionador'>Lista
        funcionários</a>
      <a href='../../Themes/Admin/registerUsersPage.php' class='defaultBtn btnRedirecionador'>Cadastrar
        func</a>
    </div>

  <?php
  } else {
  ?>

    <div class='upsideBtns'>
      <a href='../../index.php' class='defaultBtn btnRedirecionador'>Home</a>
      <a href='../../Themes/App/registerItemsPage.php' class='defaultBtn btnRedirecionador'>Cadastrar
        Item</a>
      <a href='../../Themes/App/itemsListPage.php' class='defaultBtn btnRedirecionador'>Lista itens</a>
    </div>
  <?php
  };
  ?>


</header>

<script>
  $(document).ready(function() {

    const uri = '<?php echo $_SERVER['REQUEST_URI']; ?>'
    const links = $('.btnRedirecionador')

    links.map((link) => {
      let el = $('.btnRedirecionador')[link]
      let attr = el.href.replaceAll("http://localhost", "");

      if (attr == uri) {
        el.style.border = "2px dotted blue"
      }
    })


  })
</script>