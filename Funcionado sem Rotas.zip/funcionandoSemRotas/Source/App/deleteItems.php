<?php

include("../Controllers/Items.php");

session_start();


$idDeleted = $_GET['deletedItem'];
$username = $_SESSION['username'];

$newItem = new Items();
$newItem->deleteItem($idDeleted, $username);
