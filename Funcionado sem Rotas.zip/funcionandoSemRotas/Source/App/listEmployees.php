<?php
include("../Controllers/User.php");

$newUser = new User(NULL, NULL, NULL);
$newUser->listEmployees();
