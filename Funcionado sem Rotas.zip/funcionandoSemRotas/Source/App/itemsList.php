<?php
include("../Controllers/Items.php");

session_start();

$newItem = new Items();
$newItem->itemList();
