<?php
include("../Controllers/User.php");

$data = filter_input_array(INPUT_POST, FILTER_DEFAULT);

$output = array();

$idDisable = $_GET['idDisable'];

$newUser = new User(NULL, $email, $password);
$newUser->DisableUser($idDisable);
