<?php

include("../Core/Connect.php");


class Items
{

  private $name;

  public function __construct(
    ?string $name = NULL,
  ) {
    $this->name = $name;
  }

  public function registerItem($quantity, $type, $location, $shelf, $username)
  {

    $data = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    $output = array();

    $bd = Connect::getInstance();

    if (!empty($this->name) && !empty($quantity) && !empty($type) && !empty($location) && !empty($shelf)) {
      $query = "INSERT INTO dataitems (itemName, itemQuantity, itemType, itemLocation, itemShelf, itemUser) VALUES (:itemName, :itemQuantity, :itemType, :itemLocation, :itemShelf, :itemUser)";
      $stmt = $bd->prepare($query);
      $stmt->bindParam(":itemName", $this->name);
      $stmt->bindParam(":itemQuantity", $quantity);
      $stmt->bindParam(":itemType", $type);
      $stmt->bindParam(":itemLocation", $location);
      $stmt->bindParam(":itemShelf", $shelf);
      $stmt->bindParam(":itemUser", $username);
    }

    if ($stmt->execute()) {
      $output['status'] = "sucesso";
    } else {
      $stmt = "";
      $output['status'] = "erro";
    }

    echo json_encode($output);
  }

  public function itemList()
  {
    $bd = Connect::getInstance();

    $query = "SELECT * FROM dataitems";


    $stmt = $bd->prepare($query);

    $stmt->execute();

    $datadb = null;
    $datadb = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $html = " ";

    foreach ($datadb as $row) {
      if ($row['is_deleted'] == 0) {
        $html .= "<tr listId=" . $row['idItem'] . ">
                <td class='inputId'>" . $row['idItem'] . "</td>
                <td class='valueName inputNome'>" . $row['itemName'] . "</td>
                <td class='valueType'>" . $row['itemType'] . "</td>            
                <td class='valueQuantity'>" . $row['itemQuantity'] . "</td>
                <td class='valueLocation'>" . $row['itemLocation'] . "</td>
                <td class='valueShelf'>" . $row['itemShelf'] . "</td>
                <td class='valueUser'>" . $row['itemUser'] . "</td>
                <td><button class='btnEdit btnList' aria-label='" . $row['idItem'] . "'>edit</button></td>
                <td><button class='btnDelete btnList'>X</button></td>
            </tr>";
      } elseif (isset($_SESSION['admin'])) {
        $html .= "<tr class='disabled' listId=" . $row['idItem'] . ">
                <td class='inputId'>" . $row['idItem'] . "</td>
                <td class='valueName inputNome'>" . $row['itemName'] . "</td>
                <td class='valueType'>" . $row['itemType'] . "</td>            
                <td class='valueQuantity'>" . $row['itemQuantity'] . "</td>
                <td class='valueLocation'>" . $row['itemLocation'] . "</td>
                <td class='valueShelf'>" . $row['itemShelf'] . "</td>
                <td class='valueUser'>" . $row['itemUser'] . "</td>
                <td><button class='btnEdit btnList' aria-label='" . $row['idItem'] . "'>edit</button></td>
            </tr>";
      }
    }

    echo $html;
  }

  public function editItems($quantity, $type, $location, $shelf, $username, $id)
  {
    $bd = Connect::getInstance();


    $query = "UPDATE dataItems SET itemName='" . $this->name . "' , itemQuantity='" . $quantity . "' , itemType='" . $type . "' , itemLocation='" . $location . "' , itemShelf='" . $shelf . "' , itemUser='" . $username . "' WHERE idItem=" . $id . ";";

    $stmt = $bd->query($query);


    $veryFica = "SELECT * FROM dataItems WHERE itemName='" . $_GET['name'] . "' AND itemQuantity='" . $_GET['quantity'] . "' AND itemType='" . $_GET['type'] . "' AND itemLocation='" . $_GET['location'] . "' AND itemShelf='" . $_GET['shelf'] . "' AND itemUser='" . $_SESSION['username'] . "' AND idItem=" . $_GET['id'] . ";";

    $stmt = $bd->prepare($veryFica);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($result as $row) {
      if ($row) exit('bombos');
      exit("not bombos");
    }


    if ($stmt->rowCount()) exit('bombs');
    exit('not bombs');
  }

  public function deleteItem($idDeleted, $username)
  {
    $bd = Connect::getInstance();


    $query = "UPDATE dataItems SET is_deleted=1, deleted_by=:deleted_by, deleted_at=CURRENT_TIME WHERE idItem=:id";
    $stmt = $bd->prepare($query);
    $stmt->bindParam(":id", $idDeleted);
    $stmt->bindParam(":deleted_by", $username);
    $stmt->execute();

    if ($stmt->rowCount()) exit(1);

    exit(0);
  }
}
