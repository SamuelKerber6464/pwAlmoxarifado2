<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../../style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <title>Document</title>
</head>
<?php
session_start();

if (!isset($_SESSION['admin'])) {
  header('Location: ../index.php');
}
?>

<body>

  <section class="modalDisable">
    <div class="insideModalDisable">
      <form class="formDisable" id="formDisable">
        <input type="hidden" class='idDisable' id="idDisable" name="idDisable">
        <h3>Confirmar Desativação:</h3>
        <div style="
        width: 100%;
         gap: 0.5rem;
          display: flex;
       flex-direction: column;">
          <input type="button" value="Sim" class="btnSubmitDisable defaultBtn">
          <input type="button" value="Não" class="btnFecharDelete defaultBtn">
        </div>
      </form>

    </div>
  </section>

  <?php
  include '../../Source/Components/Header.php';
  ?>
  <span class="statusDisableUser"></span>
  <table class="containerTable">
    <tr>
      <th>Id</th>
      <th>Username</th>
      <th>Email</th>
      <th>Desativar</th>
    </tr>
    <tbody id="tabelaDiv"></tbody>

  </table>

  </div>

  <script src="../../Assets/formsJS/listEmployees.js"></script>
</body>

</html>