$(document).ready(function () {
  const tabelaDiv = $('#tabela');
  const htmlName = $('.inputNome');
  const idTd = $('.inputId');

  const modalEdit = $('.modalEdit');
  const modalDelete = $('.modalDelete');

  const idEdit = $('.idEdit');
  const nameEdit = $('.nameEdit');
  const typeEdit = $('.typeEdit');
  const quantityEdit = $('.quantityEdit');
  const locationEdit = $('.locationEdit');
  const shelfEdit = $('.shelfEdit');

  const btnSubmitEdit = $('.btnSubmitEdit');

  const btnDelete = $('.btnDelete');

  const formEdit = $('#formEdit');
  const formDeleted = $('#formDeleted');

  const btnSubmitDelete = $('.btnSubmitDelete');
  const btnCloseDelete = $('.btnFecharDelete');

  const idDelete = $('#idDelete');

  $('#searchBar').on('keyup', function () {
    let value = $(this).val().toLowerCase();
    $('#tabela tr').filter(function () {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
    });
  });

  $.ajax({
    method: 'GET',
    url: '../../Source/App/itemsList.php',
    success: function (resp) {
      tabelaDiv.html(resp);

      $('.btnEdit').on('click', function () {
        const rowContent = $(this).parent().parent();
        const tdId = +rowContent[0].children[0].innerText;
        $('body').css('height', '100vh');
        $('body').css('overflow', 'hidden');
        modalEdit.show();

        $('#btnClose').on('click', function () {
          modalEdit.hide();
        });

        modalEdit.on('click', function ({ target }) {
          if (target === $(this)[0]) {
            modalEdit.hide();
          }
        });

        idEdit.val(rowContent[0].children[0].innerText);
        nameEdit.val(rowContent[0].children[1].innerText);
        typeEdit.val(rowContent[0].children[2].innerText);
        quantityEdit.val(rowContent[0].children[3].innerText);
        locationEdit.val(rowContent[0].children[4].innerText);
        shelfEdit.val(rowContent[0].children[5].innerText);

        /* */

        btnSubmitEdit.on('click', function (e) {
          e.preventDefault();

          const formData = formEdit.serialize();

          $.ajax({
            method: 'GET',
            url: `../../Source/App/editItems.php?${formData}`,
            success: function (data) {
              alert('Atualização feita com sucesso');
              modalEdit.hide();
              location.reload();
            },
          });
        });
      });

      $('.btnDelete').on('click', function () {
        const rowContent = $(this).parent().parent();
        const tdId = +rowContent[0].children[0].innerText;
        modalDelete.show();

        idDelete.val(+rowContent[0].children[0].innerText);

        modalDelete.on('click', function ({ target }) {
          if (target === $(this)[0]) {
            modalDelete.hide();
          }
        });

        btnSubmitDelete.on('click', function (e) {
          const formData = formDeleted.serialize();

          $.ajax({
            method: 'GET',
            url: `../../Source/App/deleteItems.php?${formData}`,
            success: function (data) {
              console.log(formData);
              alert('Delete feito com sucesso');
              modalDelete.hide();
              location.reload();
            },
          });
        });
      });

      btnCloseDelete.on('click', function (e) {
        e.preventDefault();
        modalDelete.hide();
      });
    },
    error: function (resp) {
      console.log('erro');
    },
  });
});
