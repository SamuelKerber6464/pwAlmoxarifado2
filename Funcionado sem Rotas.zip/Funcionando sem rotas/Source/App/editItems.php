<?php

include("../Controllers/Items.php");

session_start();

$name = $_GET['name'];
$quantity = $_GET['quantity'];
$type = $_GET['type'];
$location = $_GET['location'];
$shelf = $_GET['shelf'];
$username = $_SESSION['username'];
$id = $_GET['id'];

$newItem = new Items($name);
$newItem->editItems($quantity, $type, $location, $shelf, $username, $id);
