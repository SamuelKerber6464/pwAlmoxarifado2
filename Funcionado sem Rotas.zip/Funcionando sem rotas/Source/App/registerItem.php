<?php

include("../Controllers/Items.php");

session_start();

$data = filter_input_array(INPUT_POST, FILTER_DEFAULT);

$output = array();

$name = $data['name'];
$quantity = $data['quantity'];
$type = $data['type'];
$location = $data['location'];
$shelf = $data['shelf'];
$username = $_SESSION['username'];

$newItem = new Items($name);
$newItem->registerItem($quantity, $type, $location, $shelf, $username);
