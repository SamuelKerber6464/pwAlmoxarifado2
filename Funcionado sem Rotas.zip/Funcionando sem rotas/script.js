import { Modal } from './Assets/frontJS/Modal.js';
import { Accordion } from './Assets/frontJS/Accordion.js';
import { ScrollSuave } from './Assets/frontJS/scrollSuave.js';

const modal = new Modal('.btnModalLogin', '.btnFechar', '.modalLogin');
modal.init();

const accordion = new Accordion('[data-anime="accordion"] dt');
accordion.init();

const scrollSuave = new ScrollSuave('[data-menu="suave"] a[href^="#"]');
scrollSuave.init();
