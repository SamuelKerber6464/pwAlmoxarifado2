<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../../style.css">
  <title>Document</title>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
</head>
<?php

session_start();

if (!isset($_SESSION['logged'])) {
  header('Location: ../index.php');
}
?>

<body>
  <?php
  include '../../Source/Components/Header.php';
  ?>
  <section class="modalDelete" class="idDelete">
    <div class="insideModalDelete">
      <form id="formDeleted" class="formDeleted">
        <input type="hidden" class='idDelete' id="idDelete" name="deletedItem">
        <h3 class="titleDelete">Confirmar Delete:</h3>
        <p id="itemDel"></p>
        <div style="
        width: 100%;
         gap: 0.5rem;
          display: flex;
       flex-direction: column;">

          <input type="button" value="Sim" class="btnSubmitDelete btnConfirm button">
          <input type="button" value="Não" class="btnFecharDelete btnCancel button">
        </div>
      </form>
    </div>
  </section>

  <section class="modalEdit">
    <div class="insidemodalEdit">
      <span id="btnClose">&times;</span>
      <form class="formEdit" id="formEdit">
        <input type="hidden" class='idEdit' name="id" style="display: none;">

        <div>
          <label for=" name">Nome</label>
          <input type="text" class="nameEdit" name="name">
        </div>
        <div>
          <label for="tipo">Tipo</label>
          <input type="text" name="type" class="typeEdit">
        </div>
        <div>
          <label for="nome">Quantidade</label>
          <input type="text" name="quantity" class="quantityEdit">
        </div>
        <div>
          <label for="nome">Localização</label>
          <input type="text" name="location" class="locationEdit">
        </div>
        <div>
          <label for="nome">Prateleira</label>
          <input type="text" name="shelf" class="shelfEdit">
          <input type="submit" value="Enviar" class="btnSubmitEdit">
        </div>
        <span>Preencha apenas um campo por envio</span>
      </form>
    </div>
  </section>



  <div class="flex-table">

    <header>

    </header>


    <input type="text" class="searchBar" id="searchBar">
    <span class="statusDelete" id="status"></span>

    <table class="containerTable">
      <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Tipo</th>
        <th>Quantidade</th>
        <th>Localização</th>
        <th>Prateleira</th>
        <th>Cadastrado por:</th>
        <th>Editar</th>
        <th>Remover</th>
      </tr>
      <tbody id="tabela">

      </tbody>


    </table>
  </div>

  <script src="../../Assets/formsJS/itemsList.js"></script>
</body>

</html>